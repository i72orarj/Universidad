//helloworld.cc
//a program that prints the inmortal saying "hello world"
#include <iostream>

int main(int argc, char const *argv[]) {
  std::cout << "hello world\n";
  return 0;
}
