#include "dados.h"

int main(int argc, char const *argv[]) {
  Dados a,b;
  std::cin >> a;
  std::cin >> b;
  std::cout << a <<'\n'<< b << '\n';
  return 0;
}
