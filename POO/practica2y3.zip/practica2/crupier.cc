//#include "persona.h"
#include "crupier.h"

using namespace std;

/*Crupier::Crupier(string dni,string codigo){
  codigo_=codigo;
  Persona(dni);
}
Crupier::Crupier(string dni,string codigo,string nombre="",string apellidos="",int edad=0,string direccion="",string localidad="",string provincia="",string pais=""):Persona(dni,nombre,apellidos,edad,direccion,localidad,provincia,pais){
  setCodigo(codigo);
  //Persona(dni,nombre,apellidos,edad,direccion,localidad,provincia,pais);
}*/
