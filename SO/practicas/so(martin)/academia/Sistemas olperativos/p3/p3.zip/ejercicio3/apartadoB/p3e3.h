#ifndef P3E3_H
#define P3E3_H

#define MAX_BUFFER 5	//Indica la cantidad de huecos que tiene nuestro array para simular el buffer

void * producir (void * arg);
void * consumir (void * arg);


#endif
