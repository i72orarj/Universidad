var searchData=
[
  ['implementación_20de_20un_20monomio',['Implementación de un monomio',['../index.html',1,'']]]
];
