#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <csignal>
#include <string>
#include <regex>
#include <algorithm>
#include <cstring>
#include <ctime>
#include <vector>
#include <map>
#include <unistd.h> // close()

bool salir = false;

struct Jugador{
    char usuario;
    string constraseña;
};

void manejador(int sigsum){
    std::cout << std::endl << "Saliendo..." << std::endl;
    salir = true;
    signal(SIGINT, manejador);
}

int main(){
   
    int sock, nuevo_socket;
    int salida;
    sockaddr_in servidor, cliente;
    bool encontrado = false;
    char buffer[250];
    std::string buffer_string;
    fd_set read_fds, aux_fds;
    int on, ret;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock == -1){
        std::cerr << "No se puede abrir el socket cliente" << std::endl;
        exit(-1);
    }

    on = 1;
    ret = setsockopt( sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));//no bloquear puerto

    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(2050);
    servidor.sin_addr.s_addr = htonl(INADDR_ANY);

    if( bind(sock, (sockaddr *) &servidor, sizeof(servidor)) == -1 ){//reservar el puerto 2050
        std::cerr << "No se pudo hacer bind" << std::endl;
        close(sock);
        exit(-1);
    }

    socklen_t cliente_len = sizeof(cliente);

    if(listen(sock, 1) == -1){//escuchar por el puerto 2050
        std::cerr << "No se pudo hacer listen" << std::endl;
        close(sock);
        exit(-1);
    }

    FD_ZERO(&read_fds);
    FD_ZERO(&aux_fds);
    FD_SET(sock, &read_fds);
    FD_SET(0, &read_fds);

    signal(SIGINT, manejador);
    while(true){
        if(salir){
            for(auto it = p_buffer.begin() ; it != p_buffer.end() ; ++it){
                send(it->get_socket(), "Desconexión del servidor", strlen("Desconexión del servidor"), 0);
                close(it->get_socket());
                FD_CLR(it->get_socket(), &read_fds);

            }
            close(sock);
            exit(EXIT_SUCCESS);
        }
        aux_fds = read_fds;
        salida = select(FD_SETSIZE, &aux_fds, NULL, NULL, NULL);//esperar
        if(salida > 0){
            for(int i = 0 ; i < FD_SETSIZE ; ++i){
                if(FD_ISSET(i, &aux_fds)){
                    if(i == sock){
                        if((nuevo_socket = accept(sock, (sockaddr *) &cliente, &cliente_len)) == -1 ){
                            std::cerr << "Error aceptando peticiones" << std::endl;
                        }
                        else{
                            if(p_buffer.size() < MAX_CLIENTES){
                                jugador p;
                                /*p.set_socket(nuevo_socket);
                                p_buffer.push_back(p);
                                FD_SET(nuevo_socket, &read_fds);
                                send(nuevo_socket, "+Ok. Usuario conectado.\n", strlen("+Ok. Usuario conectado.\n"), 0);
                            
                                */
                            }
                            else{
                                send(nuevo_socket, "-Err. Demasiados clientes conectados.\n", strlen("-Err. Demasiados clientes conectados.\n"), 0);
                                close(nuevo_socket);
                            }
                        }
                    }
                    else if(i == 0){ // Leemos de teclado.
                        std::getline(std::cin, buffer_string);
                        if( buffer_string == "SALIR" ){
                            salir = true;
                        }
                    }
                    else{
                        bzero(buffer, sizeof(buffer));
                        if( recv(i, buffer, sizeof(buffer), 0) > 0 ){
                            std::string s(buffer);
                            int peticion = manejar_peticion(s);


                        }

}                            
