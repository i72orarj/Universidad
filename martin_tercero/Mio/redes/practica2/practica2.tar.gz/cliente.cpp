#include <cstdio>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <cstdlib>
#include <cstring>
#include <arpa/inet.h>
#include <iostream>
#include <unistd.h>
#include <csignal>
#include <vector>
#include <string>


int socket_cliente;
char buffer[250];

void sigint(int signum){
  std::cout << "CTRL + C para salir" << std::endl;
  bzero(buffer, sizeof(buffer));
  send(socket_cliente, buffer, sizeof(buffer), 0);
}

int main(int argc, char const *argv[]){
  socket_cliente = socket(AF_INET, SOCK_STREAM, 0);
  if(socket_cliente == -1){
    perror("Socket error\n");
    return EXIT_FAILURE;
  }
  struct sockaddr_in sockname;
  sockname.sin_family = AF_INET;
  sockname.sin_port = htons(2050);
  sockname.sin_addr.s_addr = inet_addr("127.168.1.155");

  socklen_t len_sockname = sizeof(sockname);
  if(connect(socket_cliente, (struct sockaddr *)&sockname, len_sockname) == -1){
    perror("Error de conexion\n");
    return EXIT_FAILURE;
  }

  fd_set readfds, auxfds;
  FD_ZERO(&auxfds);
  FD_ZERO(&readfds);
  FD_SET(0, &readfds);
  FD_SET(socket_cliente, &readfds);

  std::signal(SIGINT, sigint);

  while(true){
    auxfds = readfds;
    select(socket_cliente + 1, &auxfds, NULL, NULL, NULL);

    if(FD_ISSET(socket_cliente, &auxfds)){
      bzero(buffer, sizeof(buffer));
      recv(socket_cliente, buffer, sizeof(buffer), 0);
    
      if(strcmp(buffer, "Desconexion exitosa") == 0){
        break;
      }
      if(strcmp(buffer, "error al desconectar") == 0){
        break;
      }
      if(strcmp(buffer, "error demasiados usuarios simultaneos") == 0){
        break;
      }
    }else{
      if(FD_ISSET(0, &auxfds)){
        bzero(buffer, sizeof(buffer));
        fgets(buffer, sizeof(buffer), stdin);
        send(socket_cliente, buffer, sizeof(buffer), 0);
      }
    }
  }

  close(socket_cliente);

  return EXIT_SUCCESS;
}